#include<stdio.h> 
int main() 
{ 
/* hi this is my first program*/ 
printf("Hello world\n"); 
return 0; 
}
